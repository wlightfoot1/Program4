import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ArrayUtils {

	public static List<Integer> greedyAlgorithm(int amount, int arr[]) {
		if (arr == null) {
			throw new IllegalArgumentException("Empty Array.");
		}else {
			int currentAmount = amount;
			List<Integer> arrayList = new ArrayList<Integer>();
			Arrays.sort(arr);
			for (int i = arr.length - 1; i != -1; i --) {
				while (currentAmount >= arr[i]) {
					arrayList.add(arr[i]);
					currentAmount = currentAmount - arr[i];
				}
			}
			return arrayList;
		}
	}
}
