/*
 * Brendan Smith
 * 4/13/18
 * Lab 7- a program that solves the change-making problem 
 * 		  using JUnit tests.
 */

import static org.junit.Assert.*;
import org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class testing123 {
	@Test
	void test1() {
		List<Integer> arrayList = new ArrayList<Integer>();
		List<Integer> results = new ArrayList<Integer>();
		results.add(50);
		results.add(50);
		int arr[] = {4,2,50,1};
		arrayList = ArrayUtils.greedyAlgorithm(100, arr);
		assertEquals(arrayList, results);
	}
	@Test
	void test2() {
		List<Integer> arrayList = new ArrayList<Integer>();
		List<Integer> results = new ArrayList<Integer>();
		results.add(25);
		results.add(10);
		results.add(5);
		results.add(1);
		results.add(1);
		int arr[] = {25, 1, 5, 10};
		arrayList = ArrayUtils.greedyAlgorithm(42, arr);
		assertEquals(arrayList, results);
	}
	@Test
	void test3() {
		List<Integer> arrayList = new ArrayList<Integer>();
		List<Integer> results = new ArrayList<Integer>();
		results.add(100);
		results.add(25);
		results.add(5);
		results.add(5);
		results.add(1);
		results.add(1);
		int arr[] = {100, 5, 25, 1, 50};
		arrayList = ArrayUtils.greedyAlgorithm(137, arr);
		assertEquals(arrayList, results);
	}
	@Test
	void test4() {
		int arr[] = null;
		Exception e = assertThrows(IllegalArgumentException.class, () -> { 
		ArrayUtils.greedyAlgorithm(100, arr); } );
		assertEquals("Empty Array.", e.getMessage());
	}

}


	